do local _ = {
  enabled_plugins = {
    "addrem",
    "bc",
    "supergroup",
    "msg_checks",
    "pin",
    "owner",
    "online",
    "plugins",
    "admin",
    "id",
    "del",
    "clean",
    "expiretime",
    "filter",
    "setlink",
    "setrules",
    "help",
    "leave",
    "روبات_ممنوع",
    "me"
  },
  group = {
    data = "bot/group.json"
  },
  robot = {
    384771800,
    0
  },
  sudo_users = {
   162643632,
    0
  }
}
return _
end
